$(document).ready(function () {
  function set_page_contents(contents) {
    $("#content").html(contents);
    console.log($("#content"));
  }

  function main_page() {
    page_contents = `
    <div id="main-content">
    <h1>Hello, this is Beer World!</h1>
    <p>This is a simple beer page for selling beer and beer accessories.</p>
    <div id="beer-img">Ova e slika</div>    
    </div>`;

    set_page_contents(page_contents);
  }

  main_page();

  function showOneBeer(response, a) {
    let data = response;
    let pageContents = `<img src="${data[a].image_url}" width='300px' height='500px' id = 'pictureRandom'/>`;
    let name = `<p id='name'>${data[a].name}: </p> ${data[0].brewers_tips}`;
    pageContents += name;
    let description = `${data[a].description} <br> 
    Brewed : ${data[a].first_brewed} <br>
    Alcohol: ${data[a].abv} <br>
    Bitterness: ${data[a].ibu}`;

    let food_Pairing = `Food pairing: <br>`;
    let food_Pairing_List = [];
    for (let i = 0; i < data[a].food_pairing.length; i++) {
      food_Pairing_List += `${data[a].food_pairing[i]} <br>`;
    }
    food_Pairing += food_Pairing_List;

    let button = `<br> <br> <br> <button id="go_back"> Go back </button>`;

    $("#content").html("");
    $("#content").append(pageContents);
    $("#content").append(description);
    $("#content").append(food_Pairing);
    $("#content").append(button);
    $("#go_back").on("click", (event) => {
      history.back();
    });
  }

  let baseUrl = `https://api.punkapi.com/v2/beers`;
  $("#beer-bar").on("click", function () {
    main_page();
  });

  async function getBeers(pageNumber, getOptionValue = 20) {
    let page = pageNumber;
    let beersPerPage = getOptionValue;
    let data;

    await $.ajax({
      url: `${baseUrl}?page=${page}&per_page=${beersPerPage}`,
      method: "GET",
      success: function (response) {
        data = response;
        console.log(response);
        return response;
      },
      error: function (error) {
        console.log(error);
      },
    });
    return data;
  }

  async function beers() {
    $("#content").html("");
    let page_contents_filter = `
    <div id="filters">
    <select id="beer-per-page">
    <option value="" selected disabled >Page Size</option>
    <option value='5'>5</option>
    <option value='10'>10</option>
    <option value='15'>15</option>
    </select>
    
    <select id="beer-filter">
    <option value="" disabled selected>Filter by</option>
    <option value='name'>name</option>
    <option value='alcohol'>alcohol</option>
    <option value='bitterness'>bitterness</option>
    <option value='first_brewed'>first brewed</option>
    </select>
    </div>
    
    <div id="table-page">2/14</div>
    <div id='wrap'></div>
    `;

    let res = await getBeers(1, 20);

    function renderData(response) {
      let i = 0;
      let j = 0;
      let z = 0;

      let page_contents = `<table id="beers-table">`;
      for (i = 0; i < Math.ceil(response.length / 4); i++) {
        //   let red = response[];
        let red_html = "<tr>";
        for (j = 0; j < 4; j++) {
          //     let pivo = red[j];
          if (response[z]) {
            red_html += `
            <td>
                <img src="${response[z].image_url}" width='200px' height='200px' class = 'picture'/>
                <div class="beer-name">${response[z].name}</div>
                <div class="beer-desc">${response[z].description}</div>
                <button id="beer_${response[z].id}" class="beer-btn">More Details</button>
                </td>
                
                `;
          }

          z++;
        }
        red_html += "</tr>";
        page_contents += red_html;
      }
      page_contents += `</table>`;

      $("#wrap").append(page_contents);

      for (let k = 0; k < response.length; k++) {
        $(`#beer_${response[k].id}`).on("click", function () {
          showOneBeer(response, k);
        });
      }
    }

    let content = $("#content");
    content.append(page_contents_filter);
    renderData(res);

    let getOptionValue;
    let optionValueFilter = null;

    function sortByName(res) {
      let arrayName = res.map((item) => item.name);
      let sortedElements = [];
      let sortedArray = arrayName.sort();
      for (i = 0; i < res.length; i++) {
        for (j = 0; j < res.length; j++) {
          if (sortedArray[i] === res[j].name) {
            sortedElements.push(res[j]);
          }
        }
      }
      return sortedElements;
    }

    function sortByAlcohol(res) {
      let arrayAlcohol = res.map((item) => item.abv);
      let sortedElements = [];
      let sortedArray = arrayAlcohol.sort((a, b) => b - a);
      for (i = 0; i < res.length; i++) {
        for (j = 0; j < res.length; j++) {
          if (sortedArray[i] === res[j].abv) {
            sortedElements.push(res[j]);
          }
        }
      }
      return sortedElements;
    }

    function sortByBitterness(res) {
      let arrayBit = res.map((item) => item.ibu);
      let sortedElements = [];
      let sortedArray = arrayBit.sort((a, b) => b - a);
      for (i = 0; i < res.length; i++) {
        for (j = 0; j < res.length; j++) {
          if (sortedArray[i] === res[j].ibu) {
            sortedElements.push(res[j]);
          }
        }
      }
      return sortedElements;
    }

    function sortByDate(res) {
      let arrayBit = res.map((item) => item.first_brewed);
      let sortedElements = [];
      let sortedArray = arrayBit.sort((a, b) => b.date - a.date);
      for (i = 0; i < res.length; i++) {
        for (j = 0; j < res.length; j++) {
          if (sortedArray[i] === res[j].first_brewed) {
            sortedElements.push(res[j]);
          }
        }
      }
      return sortedElements;
    }

    $("#beer-per-page").on("change", async function () {
      getOptionValue = document.getElementById(`beer-per-page`).value;
      $("#wrap").html("");
      res = await getBeers(1, getOptionValue);
      if (optionValueFilter !== null) {
        const sortedElements = sortByName(res);
        renderData(sortedElements);
      } else renderData(res);
    });

    $("#beer-filter").on("change", async function () {
      optionValueFilter = document.getElementById(`beer-filter`).value;
      let arrayName = [];
      let arrayAlcohol = [];
      let arrayBitterness = [];
      let arrayDateBrewed = [];
      let z = 0;
      let array = [];
      for (i = 0; i < res.length; i++) {
        arrayName.push(res[i].name);
        arrayBitterness.push(res[i].ibu);
        arrayAlcohol.push(res[i].abv);
        arrayDateBrewed.push(res[i].first_brewed);
      }
      switch (optionValueFilter) {
        case "name":
          const sortedElements = sortByName(res);
          $("#wrap").html("");
          renderData(sortedElements);
          break;
        case "alcohol":
          let sortedAlcohol = sortByAlcohol(res);
          $("#wrap").html("");
          renderData(sortedAlcohol);
          break;
        case "bitterness":
          let sortedBit = sortByBitterness(res);
          $("#wrap").html("");
          renderData(sortedBit);
          break;
        case "first_brewed":
          let sortedDate = sortByDate(res);
          $("#wrap").html("");
          renderData(sortedDate);
          break;
      }
    });
  }

  $("#beers").on("click", (event) => {
    event.preventDefault();
    beers();
  });

  $("#random-beer").on("click", function () {
    $.ajax({
      url: `${baseUrl}/random`,
      method: "GET",
      success: function (response) {
        console.log(response);
        showOneBeer(response, 0);
      },

      error: function (error) {
        console.log(error);
      },
    });
  });
});
